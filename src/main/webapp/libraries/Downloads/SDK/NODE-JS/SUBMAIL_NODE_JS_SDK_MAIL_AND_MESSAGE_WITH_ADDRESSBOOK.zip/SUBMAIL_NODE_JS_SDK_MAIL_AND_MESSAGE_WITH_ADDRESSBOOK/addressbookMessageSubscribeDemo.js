var AddressbookMessage = require('./addressbookMessage.js');

var addressbookMessage = new AddressbookMessage();

addressbookMessage.set_address('18610811234');

addressbookMessage.subscribe();
