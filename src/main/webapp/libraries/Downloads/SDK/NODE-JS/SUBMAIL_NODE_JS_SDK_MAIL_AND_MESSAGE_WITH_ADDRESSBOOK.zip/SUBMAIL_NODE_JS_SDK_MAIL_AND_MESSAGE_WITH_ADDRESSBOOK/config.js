var Config = {
    mailConfig : {
        appid: 'your mail appid',
        appkey: 'your mail appkey',
        signtype: 'normal'
    },
    messageConfig : {
        appid : 'your message appid',
        appkey : 'your message appkey',
        signtype : 'normal'
    }
};

module.exports = Config;
