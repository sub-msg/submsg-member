var AddressbookMail = require('./addressbookMail.js');

var addressbookMail = new AddressbookMail();

addressbookMail.set_address('jseanj@126.com');

addressbookMail.subscribe();
