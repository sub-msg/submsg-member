// submail project doc.go

/*
submail document
*/
package submail
