// SubmailDemo project doc.go

/*
SubmailDemo document
*/
package main
