//
//  SMMail.h
//  Submail
//
//  Created by zcl on 14/11/24.
//  Copyright (c) 2014年 zcl. All rights reserved.
//

#import "SMBaseTransfer.h"

@interface SMMail : SMBaseTransfer

@end
