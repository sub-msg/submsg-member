//
//  AddressbookMessageSubscribeDemo.h
//  SubmailTest
//
//  Created by zcl on 14/12/7.
//  Copyright (c) 2014年 zcl. All rights reserved.
//

#import "SubmailDemo.h"

@interface AddressbookMessageSubscribeDemo : SubmailDemo

@end
