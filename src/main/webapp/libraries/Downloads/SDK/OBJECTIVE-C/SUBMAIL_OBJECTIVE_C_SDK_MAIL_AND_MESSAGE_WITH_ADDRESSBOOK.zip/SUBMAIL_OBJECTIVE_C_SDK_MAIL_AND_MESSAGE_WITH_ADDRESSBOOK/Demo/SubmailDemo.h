//
//  SubmailDemo.h
//  SubmailTest
//
//  Created by zcl on 14/12/7.
//  Copyright (c) 2014年 zcl. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Submail.h"

@interface SubmailDemo : NSObject

+ (void)demo;

@end
