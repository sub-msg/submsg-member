//
//  SMMessage.h
//  Submail
//
//  Created by zcl on 14/11/25.
//  Copyright (c) 2014年 zcl. All rights reserved.
//

#import "SMBaseTransfer.h"

@interface SMMessage : SMBaseTransfer

@end
