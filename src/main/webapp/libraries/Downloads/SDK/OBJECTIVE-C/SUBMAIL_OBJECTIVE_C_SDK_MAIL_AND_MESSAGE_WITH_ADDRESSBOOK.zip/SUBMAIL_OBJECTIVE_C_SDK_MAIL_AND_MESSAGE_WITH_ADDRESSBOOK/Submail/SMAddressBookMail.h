//
//  SMAddressBookMail.h
//  Submail
//
//  Created by zcl on 14/11/24.
//  Copyright (c) 2014年 zcl. All rights reserved.
//

#import "SMBaseAddressBook.h"

@interface SMAddressBookMail : SMBaseAddressBook

@end
